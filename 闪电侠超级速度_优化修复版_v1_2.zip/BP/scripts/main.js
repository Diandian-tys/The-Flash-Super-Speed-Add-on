import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

const SPEED_ITEM = "flash:super_speed";
const BOOK_ITEM = "flash:speed_book";
const SERUM_ITEM = "flash:yellow_serum";
const AFTERIMAGE = "flash:afterimage";
const active = new Set();
const sprintTicks = new Map();
const lastTrail = new Map();
const lastNotice = new Map();

function getPercent(player) {
  const tag = player.getTags().find(t => t.startsWith("flash_percent_"));
  if (!tag) return 50;
  const n = Number(tag.slice(14));
  return Number.isFinite(n) ? Math.max(1, Math.min(100, n)) : 50;
}
function setPercent(player, value) {
  const percent = Math.max(1, Math.min(100, Math.round(value)));
  for (const tag of player.getTags()) {
    if (tag.startsWith("flash_percent_")) player.removeTag(tag);
  }
  player.addTag(`flash_percent_${percent}`);
  return percent;
}
function showBook(player) {
  const percent = getPercent(player);
  const form = new ActionFormData()
    .title("§b闪电侠 · 超级速度手册")
    .body(`§f当前速度：§b${percent}%\n\n§e使用方法\n§f1. 使用黄色极速血清，获得不可丢弃的绑定物品「超级速度」。\n2. 使用「超级速度」开启或关闭极速。\n3. 开启后按住冲刺键奔跑。\n4. 在下方调整 1%–100% 速度。\n\n§c极速会增加手机负载，建议逐步提高。\n\n§b本模组作者 B站：§fDiandar\n§bQQ名称：§fDiandian\n§bQQ号：§f2597872335\n§bGitHub：§fhttps://github.com/Diandian-tys\n§7作者的 GitHub 库还有更多模组。`)
    .button("§b调整跑步速度")
    .button(active.has(player.id) ? "§c关闭超级速度" : "§a开启超级速度");
  form.show(player).then(result => {
    if (result.canceled) return;
    if (result.selection === 0) {
      new ModalFormData().title("§b极速百分比")
        .slider("跑步速度（1%–100%）", 1, 100, 1, percent)
        .show(player).then(r => {
          if (r.canceled) return;
          const p = setPercent(player, r.formValues[0]);
          player.sendMessage(`§b[闪电侠] §f速度已设置为 §e${p}%§f。`);
        }).catch(() => {});
    } else {
      if (active.has(player.id)) active.delete(player.id);
      else active.add(player.id);
      player.sendMessage(`§b[闪电侠] §f超级速度已${active.has(player.id) ? "§a开启" : "§c关闭"}§f。`);
    }
  }).catch(() => {});
}
function giveBoundSpeed(player) {
  try {
    // Item-lock and keep-on-death are command/NBT components on Bedrock 1.20.
    // Re-issue the unique ability item in its locked form, replacing any old unlocked copy.
    player.runCommand(`clear @s ${SPEED_ITEM}`);
    player.runCommand(`give @s ${SPEED_ITEM} 1 0 {"minecraft:item_lock":{"mode":"lock_in_inventory"},"minecraft:keep_on_death":{}}`);
    player.sendMessage("§b⚡ 你已觉醒超级速度！「超级速度」已绑定背包，不可丢弃，并会在死亡后保留。");
  } catch (e) {
    player.sendMessage("§c背包可能已满，请腾出一个空位后重新使用血清。");
  }
}

world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => {
  if (!initialSpawn) return;
  system.runTimeout(() => {
    try {
      if (!player.hasTag("flash_intro_given")) {
        player.runCommand(`give @s ${SERUM_ITEM} 1`);
        player.runCommand(`give @s ${BOOK_ITEM} 1`);
        player.addTag("flash_intro_given");
      }
      player.sendMessage("§b闪电侠模组已就绪！§f已发放§e黄色极速血清§f和§e调速手册§f。作者：§bDiandar");
      player.sendMessage("§7作者资料与 GitHub 链接已写入手册。注射血清后获得不可丢弃的绑定能力物品。");
    } catch (e) {}
  }, 20);
});

world.afterEvents.itemUse.subscribe(({ source, itemStack }) => {
  if (!source || source.typeId !== "minecraft:player") return;
  if (itemStack.typeId === SERUM_ITEM) {
    try {
      source.runCommand(`clear @s ${SERUM_ITEM} 0 1`);
      giveBoundSpeed(source);
      source.onScreenDisplay.setTitle("§e⚡", { fadeInDuration: 0, stayDuration: 1, fadeOutDuration: 4 });
      source.onScreenDisplay.setActionBar("§b极速血清注射成功！超级速度已绑定");
      // One brief visual cue, not a burst of repeated entity spawns.
      try { source.dimension.spawnParticle("minecraft:totem_particle", {x:source.location.x, y:source.location.y+1, z:source.location.z}); } catch (e) {}
    } catch (e) { source.sendMessage("§c注射失败，请重试。"); }
  } else if (itemStack.typeId === SPEED_ITEM) {
    if (active.has(source.id)) active.delete(source.id);
    else active.add(source.id);
    source.sendMessage(`§b[闪电侠] §f超级速度已${active.has(source.id) ? "§a开启" : "§c关闭"}§f。当前：§e${getPercent(source)}%`);
  } else if (itemStack.typeId === BOOK_ITEM) {
    showBook(source);
  }
});

// High-speed movement loop. It does no work when nobody has the ability enabled.
// The configured targets are 1.5–4.5 blocks/tick (30–90 blocks/sec at 20 TPS),
// with a short burst up to 5.6 blocks/tick (112 blocks/sec). Engine collision,
// tick rate and chunk availability can reduce actual travel speed.
system.runInterval(() => {
  if (active.size === 0) return;
  for (const player of world.getAllPlayers()) {
    if (!active.has(player.id)) continue;
    if (!player.isSprinting) {
      sprintTicks.delete(player.id);
      continue;
    }
    try {
      const runTicks = (sprintTicks.get(player.id) ?? 0) + 1;
      sprintTicks.set(player.id, runTicks);
      const percent = getPercent(player);
      const view = player.getViewDirection();
      const len = Math.sqrt(view.x * view.x + view.z * view.z) || 1;
      const dx = view.x / len;
      const dz = view.z / len;
      const velocity = player.getVelocity();

      // Convert percentage to a direct horizontal velocity target, not a potion effect.
      const baseTarget = 1.5 + (percent / 100) * 3.0;
      const burst = runTicks >= 20 ? 1.1 : 0;
      const target = Math.min(5.6, baseTarget + burst);
      player.applyImpulse({
        x: dx * target - velocity.x,
        y: 0,
        z: dz * target - velocity.z
      });

      // Trail is deliberately throttled: no ghost entity every few ticks.
      // Low speed: every 14 ticks; max speed: every 8 ticks; each lasts 3 ticks.
      const now = system.currentTick;
      const previous = lastTrail.get(player.id) ?? -100;
      const trailInterval = Math.max(8, 16 - Math.floor(percent * 0.08));
      if (percent >= 20 && now - previous >= trailInterval &&
          Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z) > 0.5) {
        const ghost = player.dimension.spawnEntity(AFTERIMAGE, {
          x: player.location.x - dx * 1.25,
          y: player.location.y,
          z: player.location.z - dz * 1.25
        });
        ghost.setRotation(player.getRotation());
        lastTrail.set(player.id, now);
        system.runTimeout(() => { try { ghost.remove(); } catch (e) {} }, 3);
      }

      if (percent >= 90 && now - (lastNotice.get(player.id) ?? 0) > 200) {
        player.onScreenDisplay.setActionBar("§b⚡ 极速模式：§e" + percent + "% §7| 高负载");
        lastNotice.set(player.id, now);
      }
    } catch (e) {}
  }
}, 1);

// Clear transient per-player state on leave to avoid stale memory.
world.afterEvents.playerLeave.subscribe(({ playerId }) => {
  active.delete(playerId);
  sprintTicks.delete(playerId);
  lastTrail.delete(playerId);
  lastNotice.delete(playerId);
});
