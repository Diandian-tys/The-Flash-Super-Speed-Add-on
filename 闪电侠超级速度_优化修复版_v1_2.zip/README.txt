闪电侠超级速度 · 性能优化与绑定物品版
目标：Minecraft Bedrock 1.20.0+
版本：1.2.0

重要修复：
1. 超级速度物品不再把 minecraft:item_lock 错放在自定义物品 JSON components 中。基岩版 1.20 的 item_lock / keep_on_death 是通过 /give 的物品 NBT 参数赋予，因此注射血清时会先清理旧的超级速度物品，再发放带 lock_in_inventory 与 keep_on_death 的版本。物品栏会显示黄色锁定角标，不可丢弃，并在死亡后保留。
2. BP manifest 的资源包依赖 UUID 和版本与 RP header 完全一致；@minecraft/server 1.2.0 和 @minecraft/server-ui 1.0.0 对应 1.20.0 API。
3. 性能优化：无玩家开启能力时速度循环立即退出；虚影生成频率降低（最高每 8 tick 一次），每个虚影 3 tick 后移除；注射只生成一次提示粒子；清理离线玩家状态。
4. 速度目标调整为 1.5–4.5 格/tick（理论 30–90 格/秒），持续冲刺后短时目标最高 5.6 格/tick（理论 112 格/秒）。这是脚本目标，不保证游戏实际速度；引擎碰撞、帧率、TPS、地形和区块加载都会影响结果。

关于预加载：
Minecraft Bedrock 1.20 的稳定 Script API 没有可供此脚本安全、动态预加载玩家前方区块的通用接口。用 tickingarea 持续追踪玩家会增加常驻区块和内存负担，反而可能使手机更卡，所以本版没有偷偷创建永久 tickingarea。已采用降低实体生成频率、空闲时停止处理等低负载优化。

安装：
导入此 mcaddon 后，在世界设置的行为包和资源包列表中都启用“闪电侠超级速度”对应包。BP 会依赖并自动请求同 UUID/版本的 RP。若之前旧版已启用，请先从世界移除旧 BP/RP，再导入 1.2.0；不要只启用 BP 而忽略 RP。
作者：B站 Diandar；QQ名称 Diandian；QQ号 2597872335；GitHub https://github.com/Diandian-tys
